# Rapport de conversion — `assurance-tns`

- **Page source** : `assurance-tns.html` (dépot GitHub, export Webflow)
- **Domaine cible** : https://assurance-tns.lp.comparateurpro.fr
- **Date** : 2026-10-22

## Résultat
| Indicateur | Valeur |
|---|---|
| Fichiers totaux | 56 |
| Poids total | 5.90 Mo |
| Images rapatriées | 44 |
| Polices rapatriées | 7 |
| CSS finale | 175 Ko |
| JS finale | 1453 Ko |
| Assets introuvables | 0 |

## SEO
- H1 : **1** ✔ (finition appliquée : 8 H1 secondaires démovés en H2, sans impact visuel — les classes Webflow portent les styles)
- GTM : GTM-53SH7D7F
- Éléments ajoutés automatiquement : meta description (auto — à relire), canonical
- Liens vers d'autres pages du dépôt (à trancher) : aucun

## Hôtes externes encore appelés par la page
assurance-tns.lp.comparateurpro.fr, www.googletagmanager.com, www.hellolead.pro


✔ Aucun avertissement, aucune référence cassée.

## Checklist QA humaine avant mise en ligne
1. Comparaison visuelle côte à côte avec la page Webflow d'origine.
2. Parcours complet du formulaire (toutes les étapes, champs obligatoires, erreurs).
3. Test OTP SMS avec un numéro de test.
4. Vérification de la réception du lead en CRM / Google Sheets.
5. Tag Assistant : déclenchement GTM et de l'événement `formulaire_lead`.
6. Lighthouse mobile : performance et accessibilité.
7. Relire meta description (générée automatiquement) et titre.

_Généré par lp2site.py_